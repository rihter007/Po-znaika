NAudio is an open source .NET audio library written by Mark Heath (mark.heath@gmail.com)
For more information, visit http://naudio.codeplex.com

THANKS
======
The following list includes some of the people who have contributed in various ways to NAudio, such as code contributions,
bug fixes, documentation, helping out on the forums and even donations. I haven't finished compiling this list yet, so
if your name should be on it but isn't please let me know and I will include it. Also, some people I only know by their forum
id, so if you want me to put your full name here, please also get in touch.

in alphabetical order:
Alexandre Mutel
AmandaTarafaMas
balistof
biermeester
borman11
bradb
Brandon Hansen (kg6ypi)
ChunkWare Music Software
CKing
DaMacc
eejake52
Florian Rosmann (filoe)
Giawa
Hfuy
Iain McCowan
Idael Cardaso 
ioctlLR
jbaker8935
jcameron23
jonahoffmann
jontdelorme
Kassoul
kevinxxx
Lustild
Lucian Wischik (ljw1004)
ManuN
MeelMarcel
Michael Feld 
Michael J
Nigel Redmon
Nikolaos Georgiou
Owen Skriloff
owoudenb
painmailer
Pygmy
Ray Molenkamp
Robert Bristow-Johnson
Scott Fleischman 
Sirish Bajpai
sporn
Steve Underwood
Ted Murphy
Tiny Simple Tools
Tobias Fleming
Tony Cabello
TuneBlade
topher3683
Vladimir Rokovanov
Ville Koskinen
Wyatt Rice
Yuval Naveh
Zsb
